﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.QueryString["fnm"] != null)
        //{
        //    Label1.Font.Name = Request.QueryString["fnm"].ToString();
        //    Label1.Font.Size = Convert.ToInt32(Request.QueryString["fsz"]);
        //}

        //HttpCookie ck = Request.Cookies["Myck"];
        //Label1.Font.Name= ck.Values["fnm"].ToString();
        //Label1.Font.Size = Convert.ToInt32(ck.Values["fsz"]);



    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        int num = Convert.ToInt32(TextBox1.Text);
        if (num < 0)
            args.IsValid = false;
        else
            args.IsValid = true;
    }
}