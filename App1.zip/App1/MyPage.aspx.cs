﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class MyPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!this.IsPostBack)
        {
            lblcnt.Text = Application["cnt"].ToString();

            ddlpub.Items.Add("--Select--");
            ddlpub.Items.Add("Wrox");
            ddlpub.Items.Add("BPB");
            ddlpub.Items.Add("TataMacgraw");
            ddlpub.Items.Add("Navneet");


            BookMaster obj = (BookMaster) this.Master;
           // obj.lbltext = DateTime.Now.ToLongDateString();

           Label lbl = (Label)  obj.FindControl("lbldata");
           lbl.Text = DateTime.Now.ToLongDateString();
        }
    }
    protected void b1_Click(object sender, EventArgs e)
    {
        Response.Write("WelCome......");
    }
    protected void ddlpub_SelectedIndexChanged(object sender, EventArgs e)
    {
        System.Collections.ArrayList books = new System.Collections.ArrayList();
        if (ddlpub.Text == "Wrox") 
        {
            books.Add("C");
            books.Add("C#");
            books.Add("Asp.net");
            books.Add("SharePoint");
        }
        if (ddlpub.Text == "BPB") 
        {
            books.Add("Learn C");
            books.Add("Learn C#");
            books.Add("Learns Asp.net");
            books.Add("Learrn SharePoint");
        }
        if (ddlpub.Text == "TataMacgraw") 
        {
            books.Add("Master in C");
            books.Add("Master in C#");
            books.Add("Master in Asp.net");
            books.Add("Master in SharePoint");
        }
        if (ddlpub.Text == "Navneet") 
        {
            books.Add("Javascript");
            books.Add("CSS");
            books.Add("HTML");
            books.Add("JQuery");
        }
        chkbook.DataSource = books;
        chkbook.DataBind();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //purchase
        ArrayList selbk = new ArrayList();
        foreach (ListItem i in chkbook.Items)
        {
            if (i.Selected)
                selbk.Add(i.Text);
        }
        BulletedList1.DataSource = selbk;
        BulletedList1.DataBind();

        Session["bk"] = selbk;

        Response.Redirect("Mycart.aspx");
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        //Add To Cart
        ArrayList selbk = new ArrayList();
        foreach (ListItem i in chkbook.Items)
        {
            if (i.Selected)
                selbk.Add(i.Text);
        }

        Profile.booklst = selbk;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        BulletedList1.DataSource = Profile.booklst;
        BulletedList1.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //Get Profile
        ProfileCommon obj = new ProfileCommon();
        ProfileCommon p= obj.GetProfile(TextBox1.Text);
        BulletedList1.DataSource = p.booklst;
        BulletedList1.DataBind();

    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        BulletedList1.DataSource = Profile.booklst;
        BulletedList1.DataBind();
    }
    protected void Button1_Click2(object sender, EventArgs e)
    {
        //Add To Cart
        ArrayList selbk = new ArrayList();
        foreach (ListItem i in chkbook.Items)
        {
            if (i.Selected)
                selbk.Add(i.Text);
        }

        Profile.booklst = selbk;
    }
}