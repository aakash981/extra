﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class Mycart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["bk"] != null)
        {
            ArrayList arr = Session["bk"] as ArrayList;
            BulletedList1.DataSource = arr;
            BulletedList1.DataBind();
        }
    }
}