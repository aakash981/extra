﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class viewstatedemo : System.Web.UI.Page
{
  

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
            ViewState["cnt"] = 0;
        else
        {
            ViewState["cnt"] = Convert.ToInt32(ViewState["cnt"]) + 1;
            Label1.Text = ViewState["cnt"].ToString();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //clear
        TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //save
        ViewState["name"] = TextBox1.Text;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        TextBox1.Text = ViewState["name"].ToString();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Default2.aspx?fnm=" + TextBox1.Text +"&fsz=" +TextBox3.Text);
        HttpCookie ck = new HttpCookie("Myck");
        ck.Values.Add("fnm", TextBox2.Text);
        ck.Values.Add("fsz", TextBox3.Text);

        Response.Cookies.Add(ck);

        Response.Redirect("Default2.aspx");
    }
}