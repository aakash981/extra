﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!this.IsPostBack)
        {
            DropDownList1.DataSource= Membership.GetAllUsers();
            DropDownList1.DataBind();
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Login1.UserName = DropDownList1.Text;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(TextBox1.Text,TextBox2.Text))
        {
            FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, false);
        }
        else
            Response.Write("Invalid User");


       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        MembershipUser user= Membership.GetUser(txtuname.Text);
        Label2.Text= user.Email;
    }
   
}