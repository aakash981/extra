﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DataAcess_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       Page.DataBind();
    }

    public List<string> Courses()
    {
        List<string> lst = new List<string>();
        lst.Add("C");
        lst.Add("C++");
        lst.Add("Asp.net");
        lst.Add("C#");

        return lst;
    }
}