﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Admin_CreateUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            DropDownList1.DataSource= Roles.GetAllRoles();
            DropDownList1.DataBind();
            
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Assign Role

        Roles.AddUserToRole(CreateUserWizard1.UserName, DropDownList1.Text);
    }
}